import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Board } from './components/Board';
import { ScoreBoard } from './components/ScoreBoard';
import { Gamepad2 } from 'lucide-react';

function calculateWinner(squares: (string | null)[]) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  for (const [a, b, c] of lines) {
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  return null;
}

function App() {
  const [squares, setSquares] = useState<(string | null)[]>(Array(9).fill(null));
  const [xIsNext, setXIsNext] = useState(true);
  const [scores, setScores] = useState({ X: 0, O: 0 });

  const winner = calculateWinner(squares);

  const handleClick = (i: number) => {
    if (calculateWinner(squares) || squares[i]) return;

    const newSquares = squares.slice();
    newSquares[i] = xIsNext ? 'X' : 'O';
    setSquares(newSquares);
    setXIsNext(!xIsNext);

    const gameWinner = calculateWinner(newSquares);
    if (gameWinner) {
      setScores(prev => ({
        ...prev,
        [gameWinner]: prev[gameWinner as keyof typeof prev] + 1
      }));
    }
  };

  const resetGame = () => {
    setSquares(Array(9).fill(null));
    setXIsNext(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-100 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-3 mb-8"
      >
        <Gamepad2 className="text-indigo-600" size={32} />
        <h1 className="text-4xl font-bold text-gray-800">Tic Tac Toe</h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl"
      >
        <ScoreBoard scores={scores} />
        <Board
          squares={squares}
          onClick={handleClick}
          onReset={resetGame}
          xIsNext={xIsNext}
          winner={winner}
        />
      </motion.div>
    </div>
  );
}

export default App;