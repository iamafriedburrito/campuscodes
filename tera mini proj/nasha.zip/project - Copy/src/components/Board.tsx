import React from 'react';
import { Square } from './Square';
import { motion } from 'framer-motion';
import { RefreshCw } from 'lucide-react';

interface BoardProps {
  squares: (string | null)[];
  onClick: (i: number) => void;
  onReset: () => void;
  xIsNext: boolean;
  winner: string | null;
}

export function Board({ squares, onClick, onReset, xIsNext, winner }: BoardProps) {
  const status = winner
    ? `Winner: ${winner}`
    : squares.every((square) => square)
    ? "It's a draw!"
    : `Next player: ${xIsNext ? 'X' : 'O'}`;

  return (
    <div className="flex flex-col items-center gap-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-2xl font-bold text-gray-700"
      >
        {status}
      </motion.div>
      
      <div className="grid grid-cols-3 gap-3">
        {squares.map((square, i) => (
          <Square
            key={i}
            value={square}
            onClick={() => onClick(i)}
            disabled={!!winner || !!square}
          />
        ))}
      </div>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onReset}
        className="flex items-center gap-2 px-4 py-2 text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
      >
        <RefreshCw size={20} />
        Reset Game
      </motion.button>
    </div>
  );
}