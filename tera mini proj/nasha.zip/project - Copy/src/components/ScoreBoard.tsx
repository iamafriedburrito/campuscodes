import React from 'react';
import { Trophy } from 'lucide-react';
import { motion } from 'framer-motion';

interface ScoreBoardProps {
  scores: {
    X: number;
    O: number;
  };
}

export function ScoreBoard({ scores }: ScoreBoardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex gap-8 mb-8"
    >
      <div className="flex items-center gap-2 bg-blue-100 px-4 py-2 rounded-lg">
        <Trophy className="text-blue-600" size={20} />
        <span className="font-semibold text-blue-600">X: {scores.X}</span>
      </div>
      <div className="flex items-center gap-2 bg-red-100 px-4 py-2 rounded-lg">
        <Trophy className="text-red-600" size={20} />
        <span className="font-semibold text-red-600">O: {scores.O}</span>
      </div>
    </motion.div>
  );
}