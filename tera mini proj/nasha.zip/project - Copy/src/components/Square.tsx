import React from 'react';
import { motion } from 'framer-motion';

interface SquareProps {
  value: string | null;
  onClick: () => void;
  disabled: boolean;
}

export function Square({ value, onClick, disabled }: SquareProps) {
  return (
    <motion.button
      whileHover={{ scale: disabled ? 1 : 1.05 }}
      whileTap={{ scale: disabled ? 1 : 0.95 }}
      className={`w-24 h-24 text-4xl font-bold rounded-xl shadow-md flex items-center justify-center
        ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}
        ${value === 'X' ? 'text-blue-600 bg-blue-50' : 
          value === 'O' ? 'text-red-600 bg-red-50' : 
          'bg-white hover:bg-gray-50'}`}
      onClick={onClick}
      disabled={disabled}
    >
      {value && (
        <motion.span
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
        >
          {value}
        </motion.span>
      )}
    </motion.button>
  );
}